import pulp
from utils import *
import time
import math

def solve_multiple_couriers(m, n, D, l, s, solver, instance, timeout=300):

    s.append(0)  # Append 0 to sizes (depot has no size)

    packages = list(range(n + 1))  # Include depot
    packages_no_base = packages[:-1]  # Exclude depot
    couriers = list(range(m))

    model = pulp.LpProblem("Multiple_Couriers_Problem", pulp.LpMinimize)

    # Decision variables:
    # Note: Here implicitily were have another contraint, the Integrality Constrain (Binary)
    y = [[[pulp.LpVariable(f"y_{c}_{p1}_{p2}", cat=pulp.LpBinary) for p2 in packages] for p1 in packages] for c in couriers]

    # Auxiliary variable for Miller-Tucker-Zemlin (MTZ) formulation
    u = [pulp.LpVariable(f"u_{p}", lowBound=0, upBound=n, cat=pulp.LpInteger) for p in packages_no_base]

    # Objective: Minimize the maximum distance travel by any courier
    d_max = pulp.LpVariable("d_max", lowBound=0)
    model += d_max

    # Maximum distance constraints
    for c in couriers:
        dist_c = pulp.lpSum(D[p1][p2] * y[c][p1][p2] for p1 in packages for p2 in packages)
        model += d_max >= dist_c

    ## Constraints:

    # 1_Each item assigned once
    for p in packages_no_base:
        model += pulp.lpSum(y[c][p1][p] for c in couriers for p1 in packages) == 1

    # 2_Flow conservation
    for c in couriers:
        for p1 in packages:
            model += pulp.lpSum(y[c][p1][p2] for p2 in packages) == pulp.lpSum(y[c][p2][p1] for p2 in packages)

    # 3_No self-loops
    for c in couriers:
        for p in packages:
            model += y[c][p][p] == 0

    # 4_Capacity Constraints
    for c in couriers:
        model += pulp.lpSum(s[p2] * y[c][p1][p2] for p1 in packages for p2 in packages_no_base) <= l[c]

    # 5_Each courier must start and return to the depot
    for c in couriers:
        #Starts at the depot
        model += pulp.lpSum(y[c][n][p] for p in packages) == 1 
        #Returns to the depot
        model += pulp.lpSum(y[c][p][n] for p in packages) == 1 

    # 6_Subtour elimination with MTZ formulation
    for p1 in packages_no_base:
        for p2 in packages_no_base:
            for c in couriers:
                model += u[p2] - u[p1] >= 1 - n * (1 - y[c][p1][p2])

    solver_instance = pulp.getSolver(solver, timeLimit=timeout, msg=1)
    model.solve(solver_instance)

    
    solution = [[] for _ in couriers]


    
    # Extract solution
    for c in couriers:
        index = n  # Start from depot
        tour_sequence = []
        while True:
            next_stop = None
            for p in packages:
                if p != index and y[c][index][p].value() > 0.5:  
                    next_stop = p
                    break
            if next_stop is None or next_stop == n:  
                break
            tour_sequence.append(next_stop + 1) 
            index = next_stop
        solution[c] = tour_sequence

    print(f"Solution: {solution}")
    print(f"Minimum distance: {d_max.value()}")


    savedTime = math.floor(model.solutionCpuTime)
    objetiveVal = d_max.value()


    #Managing some error

    if model.sol_status != 1: savedTime = timeout

    if any(len(tour) == 0 for tour in solution):
        solution = "N/A"
        objetiveVal = 0

    total_values = sum(len(tour) for tour in solution)
    print(total_values)

    if (total_values<n):
        solution = "N/A"
        objetiveVal = 0.0

    
    final_dict = {
            "time": savedTime, # Floor of the actual runtime 
            "optimal": model.sol_status == 1, #Solved to Optimality
            "obj": objetiveVal,
            "sol": solution
    }   

    print(final_dict)
    save_json(final_dict, solver, f"{int(instance)}.json", "res/MIP")
